export const DEFAULT_PAGE_NO = 1;
export const DEFAULT_SIZE = 10;